package session07.practice;

public class Classroom {

    public static void main(String[] args) {
        Student studentJohn = new Student();
        studentJohn.name = "John";
        studentJohn.age = 21;

        studentJohn.displayDetails();
    }
}
