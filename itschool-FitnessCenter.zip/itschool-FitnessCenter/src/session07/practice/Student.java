package session07.practice;

public class Student {

    String name;
    int age;

    public void displayDetails() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
