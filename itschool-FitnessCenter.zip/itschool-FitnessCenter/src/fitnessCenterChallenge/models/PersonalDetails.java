package fitnessCenterChallenge.models;

public class PersonalDetails {

    private String firstName;
    private String lastName;


}
