package fitnessCenterChallenge.models;

public class FitnessClass extends Activity {

    public FitnessClass(String activityName) {
        super(activityName);
    }
}
