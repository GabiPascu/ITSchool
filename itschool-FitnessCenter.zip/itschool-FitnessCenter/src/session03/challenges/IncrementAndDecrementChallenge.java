package session03.challenges;

public class IncrementAndDecrementChallenge {

    public static void main(String[] args) {
        for (int i = 0; i <= 10; i++) {
            System.out.println(i);
        }

        System.out.println("---------");

        for (int i = 10; i >= 0; i--) {
            System.out.println(i);
        }
    }
}
