package session03.challenges;

public class NumericChallenge {

    public static void main(String[] args) {

    }
}
