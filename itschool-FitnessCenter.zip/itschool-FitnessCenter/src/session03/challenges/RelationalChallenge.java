package session03.challenges;

public class RelationalChallenge {

    public static void main(String[] args) {

    }
}
