package session03.practice;

public class RelationalOperators {

    public static void main(String[] args) {
        int firstNumber = 10;
        int secondNumber = 30;

        System.out.println(firstNumber == secondNumber);
        System.out.println(firstNumber != secondNumber);
        System.out.println(firstNumber > secondNumber);
        System.out.println(firstNumber < secondNumber);
        System.out.println(firstNumber >= secondNumber);
        System.out.println(firstNumber <= secondNumber);
    }
}
