package session03.practice;

public class UnaryOperators {

    public static void main(String[] args) {
        int firstNumber = +10;
        int secondNumber = -20;

        System.out.println(firstNumber);
        System.out.println(secondNumber);
    }
}
