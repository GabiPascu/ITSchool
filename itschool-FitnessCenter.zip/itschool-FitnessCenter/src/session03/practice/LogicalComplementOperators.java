package session03.practice;

public class LogicalComplementOperators {

    public static void main(String[] args) {
        boolean isFirstTime = true;
        boolean isRegistered = false;

        System.out.println(!isFirstTime);
        System.out.println(!isRegistered);
    }
}
