package session02;

public class Test {

    public static void main(String[] args) {
        System.out.println("Hello");

        // this is a comment from main branch
    }
}
