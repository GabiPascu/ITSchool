package session10.practice.inheritance;

public class InheritanceExample {
}

class Building {

}

class Apartment extends Building {

}

class Room extends Building {

}
