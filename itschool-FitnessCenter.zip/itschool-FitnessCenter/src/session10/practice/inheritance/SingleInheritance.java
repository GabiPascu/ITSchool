package session10.practice.inheritance;

public class SingleInheritance {
}

//class Parent {
//    void displayParent() {
//        System.out.println("This is a parent class method");
//    }
//}
//
//class Child extends Parent {
//    @Override
//    void displayParent() {
//        System.out.println("This is a child class method");
//    }
//}
