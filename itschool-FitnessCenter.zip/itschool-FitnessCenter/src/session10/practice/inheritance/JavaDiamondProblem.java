package session10.practice.inheritance;

public class JavaDiamondProblem {
}

class Shape {

}

class Square extends Shape {
    void setArea() {

    }
}

class Rectangle extends Shape {
    void setArea() {

    }
}

//class Parallelogram extends Square, Rectangle {
//    // will not compile
//}