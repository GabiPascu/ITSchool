package session10.practice.inheritance;

public class CarsInheritance {
}

class Supercar {

}

class Ferrari extends Supercar {

}

class Lamborghini extends Supercar {

}
