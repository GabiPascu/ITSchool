package session08.challenges;

import java.util.Arrays;

public class Challenge01 {

    public static void main(String[] args) {
        String[] shoppingItems = {"banana", "grape", "apple", "cherries"};
        printArray(shoppingItems);
    }

    public static void printArray(String[] arr) {
        System.out.println(Arrays.toString(arr));
    }
}
