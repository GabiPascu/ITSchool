package session08.challenges;

public class Challenge09 {

    public static void main(String[] args) {
        String binary = "1011";
        String binary2 = "10101";

        int decimal = Integer.parseInt(binary, 2);
        int decimal2 = Integer.parseInt(binary2, 2);

        System.out.println(decimal);
        System.out.println(decimal2);
    }
}
