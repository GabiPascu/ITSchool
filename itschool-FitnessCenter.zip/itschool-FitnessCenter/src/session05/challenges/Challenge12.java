package session05.challenges;

public class Challenge12 {

    public static void main(String[] args) {

    }
}
