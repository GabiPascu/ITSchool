package session06.challenges;

public class Challenge9 {

    public static void main(String[] args) {
        String string = "telecommunication";
        countLetterFrequency(string);
    }

    public static void countLetterFrequency(String str) {
        StringBuilder stringBuilder = new StringBuilder();
    }
}
