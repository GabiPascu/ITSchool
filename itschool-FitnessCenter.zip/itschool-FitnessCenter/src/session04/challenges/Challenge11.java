package session04.challenges;

public class Challenge11 {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = 30;
        int d = 40;
        int additionResult = a + b;
        int multiplicationResult = c * d;

        System.out.println(additionResult);
        System.out.println(multiplicationResult);
    }
}
