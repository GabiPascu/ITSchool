package session04.challenges;

public class Challenge13 {

    public static void main(String[] args) {
        boolean isRaining = false;
        boolean isSunny = true;

        System.out.println(!isRaining);
        System.out.println(!isSunny);
    }
}
