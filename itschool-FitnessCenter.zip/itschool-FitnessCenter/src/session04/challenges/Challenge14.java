package session04.challenges;

public class Challenge14 {

    public static void main(String[] args) {
        int counter = 0;
        counter++;
        System.out.println(counter);
        counter--;
        System.out.println(counter);
    }
}
