package session04.challenges;

public class Challenge3 {

    public static void main(String[] args) {
        int age = 20;

        if (age >= 18) {
            System.out.println("This person is an adult");
        } else {
            System.out.println("This person is a minor");
        }
    }
}
