package session04.challenges;

public class Challenge15 {

    public static void main(String[] args) {
        int total = 100;
        total -= 20;
        System.out.println(total);
        total *= 7;
        System.out.println(total);
    }
}
