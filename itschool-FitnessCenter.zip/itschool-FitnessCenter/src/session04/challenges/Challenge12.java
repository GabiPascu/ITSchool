package session04.challenges;

public class Challenge12 {

    public static void main(String[] args) {
        int number = 25;
        int negativeNumber = -number;

        System.out.println(number);
        System.out.println(negativeNumber);
    }
}
