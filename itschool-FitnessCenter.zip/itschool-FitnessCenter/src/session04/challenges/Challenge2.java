package session04.challenges;

public class Challenge2 {

    public static void main(String[] args) {
        int firstNumber = 5;
        int secondNumber = 10;

        String firstStr = "Hello";
        String secondStr = "Hello";

        System.out.println(firstNumber == secondNumber);
        System.out.println(firstStr.equals(secondStr));
    }
}
