package session04.challenges;

public class Challenge16 {

    public static void main(String[] args) {
        int number = 50;
        number = -number;
        System.out.println(number);
        number = Math.abs(number);
        System.out.println(number);
        number++;
        System.out.println(number);

    }
}
