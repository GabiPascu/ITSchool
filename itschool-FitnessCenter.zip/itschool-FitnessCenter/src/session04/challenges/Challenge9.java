package session04.challenges;

public class Challenge9 {

    public static void main(String[] args) {
        String countryOne = "USA";
        String countryTwo = "USA";

        System.out.println(countryOne.equals(countryTwo));
        countryTwo = "UK";
        System.out.println(countryOne.equals(countryTwo));
    }
}
