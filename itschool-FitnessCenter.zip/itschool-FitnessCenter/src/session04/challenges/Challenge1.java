package session04.challenges;

public class Challenge1 {

    public static void main(String[] args) {
        String strOne = "OpenAI";
        String strTwo = "OpenAI";

        System.out.println(strOne.equals(strTwo));
    }
}
