package session04.challenges;

public class Challenge20 {

    public static void main(String[] args) {
        int a = 24;
        int b = 12;
        int c = 56;

        int biggerNum = Math.max(a, b);
        System.out.println("Biggest number is: " + Math.max(biggerNum, c));
    }
}
