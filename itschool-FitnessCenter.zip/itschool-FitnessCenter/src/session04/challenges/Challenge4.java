package session04.challenges;

public class Challenge4 {

    public static void main(String[] args) {
        int heightOne = 160;
        int heightTwo = 172;

        int maximumHeight = heightOne > heightTwo ? heightOne : heightTwo;
        System.out.println(maximumHeight);
    }
}
