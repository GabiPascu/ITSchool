package session04.practice;

public class TernaryOperatorPractice {

    public static void main(String[] args) {
        int number = 10;
        String result = (number > 0) ? "positive" : "negative";
        System.out.println(result);
    }
}
