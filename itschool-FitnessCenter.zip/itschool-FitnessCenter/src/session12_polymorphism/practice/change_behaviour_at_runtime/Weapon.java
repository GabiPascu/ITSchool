package session12_polymorphism.practice.change_behaviour_at_runtime;

public interface Weapon {

    void use();
}
