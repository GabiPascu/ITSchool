package session12_polymorphism.practice.has_a;

public class Engine {

    void start() {
        System.out.println("Engine has started");
    }
}
