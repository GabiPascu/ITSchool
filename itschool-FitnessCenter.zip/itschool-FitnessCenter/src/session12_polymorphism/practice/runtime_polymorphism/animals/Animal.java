package session12_polymorphism.practice.runtime_polymorphism.animals;

public class Animal {

    public String sound() {
        return "Animal makes sound";
    }
}
