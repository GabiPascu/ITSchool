package session12_polymorphism.practice.runtime_polymorphism.fruits;

public class Apple extends Fruit {

    @Override
    public String taste() {
        return "Apple is sweet";
    }
}
