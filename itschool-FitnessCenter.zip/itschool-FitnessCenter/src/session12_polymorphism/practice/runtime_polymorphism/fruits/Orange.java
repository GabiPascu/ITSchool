package session12_polymorphism.practice.runtime_polymorphism.fruits;

public class Orange extends Fruit {

    @Override
    public String taste() {
        return "Orange is tangy";
    }
}
