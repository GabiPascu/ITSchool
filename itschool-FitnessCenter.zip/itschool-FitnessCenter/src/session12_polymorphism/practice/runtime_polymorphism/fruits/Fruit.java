package session12_polymorphism.practice.runtime_polymorphism.fruits;

public class Fruit {

    public String taste() {
        return "Fruit has taste";
    }
}
