package session12_polymorphism.practice.fitness_center.models;

public class PersonalInfo {
}
