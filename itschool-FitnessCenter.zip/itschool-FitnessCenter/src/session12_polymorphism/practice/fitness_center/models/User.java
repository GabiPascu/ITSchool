package session12_polymorphism.practice.fitness_center.models;

import java.util.UUID;

public class User {

    private UUID userId;
    private PersonalInfo personalInfo;

    // getters and setters
}
