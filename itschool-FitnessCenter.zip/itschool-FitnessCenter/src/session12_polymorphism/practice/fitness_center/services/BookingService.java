package session12_polymorphism.practice.fitness_center.services;

public class BookingService {

    public void createBooking() {

    }
}
