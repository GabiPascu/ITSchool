package session12_polymorphism.practice.object_vs_reference;

public class Car extends Vehicle {

    @Override
    public String fuelType() {
        return "petrol";
    }
}
