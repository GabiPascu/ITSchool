package session12_polymorphism.practice.object_vs_reference;

public class Vehicle {

    public String fuelType() {
        return "genericFuel";
    }
}
