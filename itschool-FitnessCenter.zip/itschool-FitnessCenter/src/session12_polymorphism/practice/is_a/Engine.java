package session12_polymorphism.practice.is_a;

public class Engine {

    void start() {
        System.out.println("Engine has started");
    }
}
