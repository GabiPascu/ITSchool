package session12_polymorphism.practice.is_a;

public class Test {

    public static void main(String[] args) {
        // using inheritance
        Car car = new Car();
        car.start();
        car.drive();
    }
}
