package session12_polymorphism.practice.is_a;

public class Car extends Engine {

    void drive() {
        System.out.println("Car is driving");
    }
}
