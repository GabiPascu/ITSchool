package session12_polymorphism.challenges.fitness_center.services;

import session12_polymorphism.challenges.fitness_center.models.FitnessClass;
import session12_polymorphism.challenges.fitness_center.models.Member;

public class BookingService {

    public static void checkAvailability(FitnessClass fitnessClass) {

    }

    public static void createBooking(FitnessClass fitnessClass, Member member) {

    }
}
