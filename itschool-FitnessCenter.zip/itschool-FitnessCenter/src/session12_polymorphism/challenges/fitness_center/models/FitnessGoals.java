package session12_polymorphism.challenges.fitness_center.models;

public class FitnessGoals {
}
