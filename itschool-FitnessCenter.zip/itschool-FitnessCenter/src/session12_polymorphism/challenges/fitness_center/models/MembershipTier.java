package session12_polymorphism.challenges.fitness_center.models;

public enum MembershipTier {
    BASIC,
    PREMIUM,
    PLATINUM
}
