package session11.practice.phone_example;

public interface Chargeable {

    void charge();
}
