package session11.practice.phone_example;

public class Smartphone extends ElectronicDevice implements Chargeable{

    @Override
    public void charge() {

    }

    @Override
    void powerOn() {

    }

    @Override
    void powerOff() {

    }
}
