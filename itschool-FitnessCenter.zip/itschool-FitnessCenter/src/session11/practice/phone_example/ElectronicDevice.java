package session11.practice.phone_example;

public abstract class ElectronicDevice {

    abstract void powerOn();
    abstract void powerOff();

    // optional behaviour (methods) as concrete methods
}
