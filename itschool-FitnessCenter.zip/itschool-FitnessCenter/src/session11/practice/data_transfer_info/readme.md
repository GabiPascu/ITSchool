In a reporting system, various types of reports (like PDF, Excel, CSV)
need to be generated based on raw data.
Use an abstract class to define common properties and behaviors of a report.
Use interfaces to define specific export capabilities.