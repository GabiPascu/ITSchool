package session11.practice.data_transfer_info;

public class CSVReport extends Report implements CSVExportable {

    @Override
    public void exportToCsv() {
        // from interface
    }

    @Override
    public void showPreview() {
        // from abstract class
    }
}
