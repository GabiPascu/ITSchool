package session11.practice.data_transfer_info;

public class PDFReport extends Report implements PDFExportable {

    @Override
    public void exportToPdf() {

    }

    @Override
    public void showPreview() {

    }
}
