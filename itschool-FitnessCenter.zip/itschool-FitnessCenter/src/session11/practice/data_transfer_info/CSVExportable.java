package session11.practice.data_transfer_info;

public interface CSVExportable {

    void exportToCsv();
}
