package session11.practice.data_transfer_info;

public interface PDFExportable {

    void exportToPdf();
}
