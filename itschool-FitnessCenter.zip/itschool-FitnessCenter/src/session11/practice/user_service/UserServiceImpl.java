package session11.practice.user_service;

public class UserServiceImpl implements UserService {

    @Override
    public User createUser(User user) {
        return null;
    }

    @Override
    public void deleteUser(long id) {
        //...
    }
}
