package session11.practice.math_example;

public interface MathConstants {

    double PI = 3.146354674674;
}
