package session11.practice.vehicle_example;

public interface Refuel {

    public void refuel();
}
