package session11.challenges.challenge02;

public abstract class Bank {

    public abstract double getBalance();
}
