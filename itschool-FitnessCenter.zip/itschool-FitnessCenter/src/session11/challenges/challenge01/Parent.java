package session11.challenges.challenge01;

public abstract class Parent {

    public abstract void message();
}
