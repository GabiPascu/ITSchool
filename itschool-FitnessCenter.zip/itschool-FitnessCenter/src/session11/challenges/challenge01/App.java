package session11.challenges.challenge01;

public class App {

    public static void main(String[] args) {
        FirstChild anna = new FirstChild("Anna");
        SecondChild mary = new SecondChild("Mary");

        anna.message();
        mary.message();
    }
}
