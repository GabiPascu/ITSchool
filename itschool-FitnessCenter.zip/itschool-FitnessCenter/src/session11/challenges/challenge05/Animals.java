package session11.challenges.challenge05;

public abstract class Animals {

    public abstract void cats();
    public abstract void dogs();
}
