package session11.challenges.challenge05;

public class HomeZoo {

    public static void main(String[] args) {
        Cats kitty = new Cats();
        Dogs doggy = new Dogs();

        kitty.cats();
        doggy.dogs();
    }
}
