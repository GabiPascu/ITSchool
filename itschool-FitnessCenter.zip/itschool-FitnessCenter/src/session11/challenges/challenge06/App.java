package session11.challenges.challenge06;

public class App {

    public static void main(String[] args) {
        Area area = new Area();

        area.rectangleArea(13, 24);
        area.squareArea(2);
        area.circleArea(4.5);
    }
}
