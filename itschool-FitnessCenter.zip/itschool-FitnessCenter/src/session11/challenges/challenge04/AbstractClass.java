package session11.challenges.challenge04;

public abstract class AbstractClass {

    public AbstractClass() {
        System.out.println("This is a constructor for abstract class");
    }

    public abstract void a_method();

    public void another_method() {
        System.out.println("This is a normal method from an abstract class");
    }
}
