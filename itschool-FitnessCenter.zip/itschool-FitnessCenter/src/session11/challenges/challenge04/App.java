package session11.challenges.challenge04;

public class App {

    public static void main(String[] args) {
        SubClass subClass = new SubClass();

        subClass.a_method();
        subClass.another_method();
    }
}
